nummm=-32768
nummm=hex(nummm)
nummm=hex(int(nummm,16) + 16**4)[2:]

print(nummm)